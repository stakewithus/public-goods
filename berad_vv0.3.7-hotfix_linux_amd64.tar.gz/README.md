# Berachain


## skip-mev/slinky help
```bash
    # Add the following to your go.mod
    replace github.com/skip-mev/slinky => github.com/berachain/slinky <version>
    go env -w GOPRIVATE=github.com/berachain/slinky
    go mod tidy
```
